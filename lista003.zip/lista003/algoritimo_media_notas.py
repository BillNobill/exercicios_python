print("|-------------Média das Notas-------------|")
nota1 = input("Digite a primeira nota: ")
nota2 = input("Digite a segunda nota: ")
nota3 = input("Digite a terceira nota: ")

print("")

media = (float(nota1) + float(nota2) + float(nota3)) / 3

print(f"A média da nota é {media}!")