print("|-------------Conversão de Comprimento-------------|")
metros = input("Insira um valor em metros: ")

print("")

centimetros = float(metros) * 100
milimetros = float(metros) * 1000

print(f"O valor de {metros} metros, equivale à {centimetros} centímetros e {milimetros} milímetros.")