print("|-------------Cálculo da àrea e do Perímetro do Retângulo-------------|")
base = float(input("Digite o base do retângulo: "))
altura = float(input("Digite a altura do retângulo: "))

print("")

area = base * altura
perimetro = 2 * (base + altura)

print(f"A área do retângulo é {area} e o perímetro é {perimetro}.")
